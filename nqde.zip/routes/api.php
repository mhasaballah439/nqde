<?php

use App\Http\Controllers\Vendor\Api\AuthController;
use App\Http\Controllers\Vendor\Api\PlansController;
use App\Http\Controllers\Vendor\Api\ProductsController;
use App\Http\Controllers\Vendor\Api\SettingsController;
use App\Http\Controllers\Vendor\Api\VendorController;
use App\Http\Controllers\Vendor\Api\WarehouseController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::group(['prefix' => 'vendor/v1'],function (){
   Route::get('countries',[SettingsController::class,'countries']);
   Route::get('currencies',[SettingsController::class,'currencies']);
   Route::get('activities-types',[SettingsController::class,'activetiesTypes']);
   Route::post('country-cities',[SettingsController::class,'countryCities']);
   ######################### auth ################################
   Route::post('register',[AuthController::class,'register']);
   Route::post('login',[AuthController::class,'login']);
   Route::post('forget-password',[AuthController::class,'forgetPassword']);

});
Route::group(['middleware' => 'JwtMiddleware','prefix' => 'vendor/v1'],function (){
    ################### products #######################
    Route::post('all-categories',[ProductsController::class,'allCategories']);
    Route::post('trashed-categories',[ProductsController::class,'trashedCategories']);
    Route::post('category',[ProductsController::class,'categories']);
    Route::post('create-category',[ProductsController::class,'createCategory']);
    Route::post('update-category',[ProductsController::class,'updateCategory']);
    Route::post('delete-category',[ProductsController::class,'deleteCategory']);
    Route::post('sort-categories',[ProductsController::class,'sortCategories']);
    ######################### auth ################################
    Route::post('verify-account',[AuthController::class,'verifyAccount']);
    Route::post('resend-active-code',[AuthController::class,'resendActiveCode']);
    Route::post('logout',[AuthController::class,'logout']);
    ######################## bouquets ##################3
    Route::get('bouquets',[PlansController::class,'bouquets']);
    Route::post('bouquet-details',[PlansController::class,'bouquetDetails']);
    Route::post('subscribe-bouquet',[PlansController::class,'subscribePlan']);
    ######################### vendor data ###################
    Route::get('vendor-data',[VendorController::class,'vendorData']);

    ############################# stock #######################
    Route::post('stock-categories',[WarehouseController::class,'stockCategories']);
    Route::post('stock-trashed-categories',[WarehouseController::class,'stockTrashedCategories']);
    Route::post('add-stock-categories',[WarehouseController::class,'addStokCategory']);
    Route::post('delete-stock-categories',[WarehouseController::class,'deleteStokCategory']);
    ############# store house ###########
    Route::post('store-house',[WarehouseController::class,'storeHouse']);
    Route::post('active-store-house',[WarehouseController::class,'activeStoreHouse']);
    Route::post('inactive-store-house',[WarehouseController::class,'deactiveStoreHouse']);
    Route::post('add-stock-categories',[WarehouseController::class,'addStoreHouse']);
    Route::post('delete-stock-categories',[WarehouseController::class,'deleteStoreHouse']);
});

<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class VendorNotificationEnableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}

<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class StockCategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}

<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class NqdeStoreCartProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}

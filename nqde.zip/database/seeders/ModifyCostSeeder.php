<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class ModifyCostSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}

<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class VendorAttributeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}

<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class NqdeStoreOrderSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}

<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use JWTAuth;
use Exception;

class JwtMiddleware
{
    public function handle($request, Closure $next)
    {
        $request->headers->set('Accept', 'application/json');
        $request->headers->set('Content-Type', 'application/json');
        $request->headers->set('Charset', 'utf-8');

        try {
            $user = JWTAuth::parseToken()->authenticate();

        } catch (\Exception $e) {
            if ($e instanceof \Tymon\JWTAuth\Exceptions\TokenInvalidException) {
                return response()->json(['status'=>401,'msg' => 'INVALID TOKEN']);
            } else if ($e instanceof \Tymon\JWTAuth\Exceptions\TokenExpiredException) {
                return response()->json(['status'=>401,'msg' => 'EXPIRED TOKEN']);
            } else {
                return response()->json(['status'=>401,'msg' => 'TOKEN NOTFOUND']);
            }
        } catch (\Throwable $e) {
            if ($e instanceof \Tymon\JWTAuth\Exceptions\TokenInvalidException) {
                return response()->json(['status'=>401,'msg' => 'INVALID TOKEN']);
            } else if ($e instanceof \Tymon\JWTAuth\Exceptions\TokenExpiredException) {
                return response()->json(['status'=>401,'msg' => 'EXPIRED TOKEN']);
            } else {
                return response()->json(['status'=>401,'msg' => 'TOKEN NOTFOUND']);
            }
        }

        if (!$user)
            response()->json([trans('Unauthenticated')]);
        return $next($request);
    }
}

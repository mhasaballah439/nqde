<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VenodrDiscountBranch extends Model
{
    use HasFactory;
    protected $table = 'venodr_discount_branches';
    protected $guarded = [];
}

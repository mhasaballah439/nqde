<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GiftCardTags extends Model
{
    use HasFactory;

    protected $table = 'gift_card_tags';
    protected $guarded = [];

}
